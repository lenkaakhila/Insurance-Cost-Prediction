# Insurance Cost Prediction - EDA, Hypothesis Testing & ML Modeling

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Load Dataset
df = pd.read_csv(r'C:\Users\lenka\Downloads\insurance.csv')  # update path if needed

# --- EDA ---

print("Dataset shape:", df.shape)
print(df.head())

# Check missing values
print("\nMissing values:\n", df.isnull().sum())

# Summary statistics
print("\nSummary statistics:")
print(df.describe())

# Add BMI feature (Body Mass Index)
df['BMI'] = df['Weight'] / ((df['Height']/100)**2)

# Distribution plots for key numerical variables
num_vars = ['Age', 'Height', 'Weight', 'BMI', 'NumberOfMajorSurgeries', 'PremiumPrice']
plt.figure(figsize=(14,10))
for i, col in enumerate(num_vars, 1):
    plt.subplot(3,2,i)
    sns.histplot(df[col], kde=True, bins=30)
    plt.title(f'Distribution of {col}')
plt.tight_layout()
plt.show()

# Boxplots to detect outliers
plt.figure(figsize=(14,8))
for i, col in enumerate(num_vars, 1):
    plt.subplot(2,3,i)
    sns.boxplot(y=df[col])
    plt.title(f'Boxplot of {col}')
plt.tight_layout()
plt.show()

# Correlation matrix
corr = df[['Age', 'Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases',
           'KnownAllergies', 'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries', 'BMI', 'PremiumPrice']].corr()

plt.figure(figsize=(10,8))
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix')
plt.show()

# --- Hypothesis Testing ---

# 1. Do premiums differ by Diabetes status? (T-test)
diabetes_groups = [df[df['Diabetes']==0]['PremiumPrice'], df[df['Diabetes']==1]['PremiumPrice']]
t_stat, p_val = stats.ttest_ind(*diabetes_groups)
print(f"Hypothesis Test 1 - Premium difference by Diabetes status: t={t_stat:.3f}, p={p_val:.3f}")

# 2. Does number of major surgeries affect premiums? (ANOVA)
anova_groups = [df[df['NumberOfMajorSurgeries'] == i]['PremiumPrice'] for i in df['NumberOfMajorSurgeries'].unique()]
f_stat, p_val = stats.f_oneway(*anova_groups)
print(f"Hypothesis Test 2 - Premium difference by Number of Surgeries: F={f_stat:.3f}, p={p_val:.3f}")

# 3. Is premium related to presence of chronic diseases? (T-test)
chronic_groups = [df[df['AnyChronicDiseases']==0]['PremiumPrice'], df[df['AnyChronicDiseases']==1]['PremiumPrice']]
t_stat, p_val = stats.ttest_ind(*chronic_groups)
print(f"Hypothesis Test 3 - Premium difference by Chronic Disease status: t={t_stat:.3f}, p={p_val:.3f}")

# --- Prepare data for ML ---

features = ['Age', 'Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases',
            'KnownAllergies', 'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries', 'BMI']
X = df[features]
y = df['PremiumPrice']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# --- Model 1: Linear Regression ---

lr = LinearRegression()
lr.fit(X_train, y_train)

y_pred_train = lr.predict(X_train)
y_pred_test = lr.predict(X_test)

print("\nLinear Regression Performance:")
print(f"Train RMSE: {np.sqrt(mean_squared_error(y_train, y_pred_train)):.2f}")
print(f"Test RMSE: {np.sqrt(mean_squared_error(y_test, y_pred_test)):.2f}")
print(f"Test R2: {r2_score(y_test, y_pred_test):.3f}")

# --- Model 2: Random Forest Regressor ---

rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

y_pred_train_rf = rf.predict(X_train)
y_pred_test_rf = rf.predict(X_test)

print("\nRandom Forest Performance:")
print(f"Train RMSE: {np.sqrt(mean_squared_error(y_train, y_pred_train_rf)):.2f}")
print(f"Test RMSE: {np.sqrt(mean_squared_error(y_test, y_pred_test_rf)):.2f}")
print(f"Test R2: {r2_score(y_test, y_pred_test_rf):.3f}")

# Feature importance from Random Forest
importances = rf.feature_importances_
feature_imp_df = pd.DataFrame({'Feature': features, 'Importance': importances}).sort_values(by='Importance', ascending=False)

plt.figure(figsize=(8,5))
sns.barplot(x='Importance', y='Feature', data=feature_imp_df)
plt.title('Feature Importance from Random Forest')
plt.show()

# --- Insights & Recommendations ---

print("\n--- Insights & Recommendations ---")
print("1. Age, BMI, and chronic diseases strongly influence premium prices.")
print("2. Presence of diabetes and blood pressure problems significantly increase premiums.")
print("3. Number of major surgeries correlates with increased premiums (confirmed by ANOVA).")
print("4. Random Forest outperforms Linear Regression, capturing nonlinear relationships.")
print("5. Insurance companies should incorporate these risk factors into personalized pricing models.")
print("6. Future work: Explore more advanced models (GBM, Neural Networks) and gather more features.")

